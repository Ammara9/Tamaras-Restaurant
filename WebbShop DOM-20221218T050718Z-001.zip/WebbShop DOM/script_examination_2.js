const products =
[
    { "image":"images/Iphone11.jpg",
      "name":"Iphone 11",
      "description":"This Iphone is from 2020",
      "price": 5000 + "kr",
    },
    { "image":"images/iphone 12.jpg",
      "name":"Iphone 12",
      "description":"This Iphone is from 2021",
      "price": 8000 + "kr",
    },
    { "image":"images/macbook.jpg",
      "name":"MacBook Air 2020",
      "description":"This MacBook Air is from 2020",
      "price": 10000 + "kr"
    }
];


// producera den HTML-kod som behövs för att presentera varje produkt
function renderProducts() {
  const template = `
  <img width="300px">
<div class="product">
     <h2 class="name"></h2>
     <p class="description"></p>
     <p class="dimension"></p>
     <p class="care"></p>
     <h2 class="price"></h2>
    <button class="add">Add to cart</button>
</div>
`; 
const container = document.getElementById("items");
for (let product of products){
  let item = document.createElement("div");
  item.innerHTML = template;
  item.querySelector("img").src = product.image;
  item.querySelector(".name").textContent = product.name;
  item.querySelector(".description").textContent = product.description;
  item.querySelector(".care").textContent = product.care;
  item.querySelector(".price").textContent = product.price;
  item.querySelector(".add").addEventListener("click", () => increment(product.name));
  container.appendChild(item);
}
}
  
//Produkter lagras som en array vars nycklar är produkternas namn
let protocol = {};

//Vi börjar med att sätta antalet till 0 för varje produkt
function initProtocol () {
    for (let product of products) {
      protocol[product.name]  = 0;
    }
}
// här skapar vi varukorgen 
function renderProtocol() {
  let tbody = document.querySelector("#cart > tbody");
  tbody.innerHTML = "";
  for (let product of products) {
      let row = tbody.insertRow(-1);
      let cellName = row.insertCell(-1);
      let cellAmount = row.insertCell(-1);
      let cellPrice = row.insertCell(-1);
	    let amount = protocol[product.name];
      cellName.textContent = product.name;
      cellAmount.textContent = amount;
      cellPrice.textContent =  parseInt(product.price) * amount + " kr";
  
    document.getElementById("button").innerHTML = '<input value="Buy" type="button" onclick="cheakOut()" id="buy_button"/> ';
  }                                     
  }


//Ökar antalet för var produkt med 1 och renderar om produkttabellen
function increment(name) {
  //console.log("Name: " + name);
   protocol[name]++; 
    renderProtocol();
	
}
window.onload = function() {
  renderProducts();
  initProtocol ();
  renderProtocol();
}
function cheakOut(){
  let tableOnePrice = document.getElementById('cart').rows[1].cells[2].innerHTML; // Skapar en variabel, hämtar värde av priset från varukorgens respektive rader och celler
  let tableTwoPrice = document.getElementById('cart').rows[2].cells[2].innerHTML; // Skapar en variabel, hämtar värde av priset från varukorgens respektive rader och celler
  let tableThreePrice = document.getElementById('cart').rows[3].cells[2].innerHTML; // Skapar en variabel, hämtar värde av priset från varukorgens respektive rader och celler
  let all_prices = parseInt(tableOnePrice) +  parseInt(tableTwoPrice) + parseInt(tableThreePrice); // Skapar en variabel, sätter ett värde av priset från det hämtade (se ovanför), och plusar ihop dom

  let tableOneAmount = document.getElementById('cart').rows[1].cells[1].innerHTML; // Skapar en variabel, hämtar värde av antal från varukorgens respektive rader och celler
  let tableTwoAmount = document.getElementById('cart').rows[2].cells[1].innerHTML; // Skapar en variabel, hämtar värde av antal från varukorgens respektive rader och celler
  let tableThreeAmount = document.getElementById('cart').rows[3].cells[1].innerHTML; // Skapar en variabel, hämtar värde av antal från varukorgens respektive rader och celler
  let all_Amount = parseInt(tableOneAmount) +  parseInt(tableTwoAmount) + parseInt(tableThreeAmount); // Skapar en variabel, sätter ett värde av antal från det hämtade (se ovanför), och plusar ihop dom
 
  document.getElementById("buy_button").addEventListener("click", cheakOut); // Hämtar upp id från html, och plockar upp köpknappen, skapar ett event, anropar funktionen cheakOut
  // Hämtar upp id från html, och plockar upp vart texten nedan ska skrivas ut
  document.getElementById("message").textContent = " You have "+ all_Amount + " pieces of products in the shopping cart, and the total amount will be " + all_prices + " Kr" ;

}







