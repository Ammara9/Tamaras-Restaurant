//DATATYPES
// var- function scope
// let block scope

// constant, const

//Numbers
let hex = 0x2A;
let binary = 0b1010;
let octal = 0o52;
let sixtyMillion = 6e7; //6 followed by 7 zeros
let NaN = 10 * "oops"; //not a numbeer
let infinity = 9 / 0;

4 + 4
55 - 22

// math functions

Math.abs (x) ;
Math.max (x, y) ;
Math.min (x, y) ;


// strings 
let poetry = "one fish \ntwo fish"; //newline

let windowsFilePath = "C:\\Documents\\some-files.js";
//boolean  

//FALSELY VALUES IN JS boolean
1. // ""
2. // 0
3. // NaN
4. // on
5. // null
6. // undefined
7. // flase

//OBJECT DATATYPE
let person = {
    name: "john",
    age: 35,
    color: "brown",
};

// arrays datatypes list of arranged values

let array =  [1, 2, 3, 4, 5, 6,];

array[0];
array.length;
