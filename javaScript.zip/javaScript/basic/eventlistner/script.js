// here we declare the constat name clearBtn and this will get a element with its id #clear by querryselector
const clearBtn = document.querySelector('#clear');


// // normal function
// clearBtn.onclick = function(){
//     alert('item cleared');
// };

// // Javacsript addeventlistner with two arguments
// clearBtn.addEventListener('click', function(){
//     alert('cleared');
// });

// // arrow function
// clearBtn.addEventListener('click', ()=> alert('cleared'));
// // with el v can add as many as we want
// clearBtn.addEventListener('click', ()=> console.log('cleared'));

function onClear(){
    const itemList = document.querySelector('ul');

    itemList.innerHTML = '';
}
clearBtn.addEventListener('click', onClear);

//setTimeout is a func to set time when its start working
// setTimeout(() => clearBtn.removeEventListener('click', onClear),5000);  //it removed the clear funct after 5 sec//

// setTimeout(() => clearBtn.click(), 5000); //the time we open webbläsaren, it wait for 5 sec then clicked it automaticaly//

