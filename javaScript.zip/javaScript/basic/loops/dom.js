// console.log(document.links[0]); //can get html a link with array//

// Methods on ducument
// document.write('hello JS'); //write directly on browser//

// ID
console.log(document.getElementById('main'));

const main = document.getElementById('main');

// ID in QUERRY SELECTOR #
document.querySelector('#main, h1').innerText = 'hello'; //dom intre h1 will change to hello//

