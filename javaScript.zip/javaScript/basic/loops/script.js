// // // for  loops
// // // let use
// // // i++, i = i + 2()
// // // if else statment in for loop
// // // nest loop in for loop
// // // in nested loop dont use i use j
// // // loop through an array
// // //
// // //
// // //
// // //
// // USES WHEN KNOW NUMBER OF TIMES LOOP RUN
// // for (let i = 0; i <= 10; i++) {
// //     if (i === 7){
// //         console.log('7 is my fav num');
// //     } else {
// //         console.log('Number is ' + i);
// //     }
// // }

// // // Nested loops
// // for (let i = 0; i <= 5; i++) {
// //     console.log('Number is ' + i);

// //     for (let j = 0; j <= 2; j++){
// //         console.log(`${i} - ${j} = ${i - j}`);
// //     }
// // }

// // for (let i = 0; i <= 10; i++){

// // }

// // const names = ['sara', 'ammara', 'aniya'];

// // for(let i = 0; i < names.length; i++){
// //     if (i === 1){
// //         console.log(names[i] + ' is here');
// //     }
// //     console.log(names[i]);
// // }

// // // BRAEK AND CONTINUE
// // // BREAK (break entire loop)
// // for (let i = 0; i <= 20; i++){
// //     if ( i === 15) {
// //         console.log('breaking...');
// //         break;
// //     }
// //     console.log(i);
// // }
// // // Continue (just skipp one number n continue)
// // for (let i = 0; i <= 20; i++){
// //     if ( i === 15) {
// //         console.log('skipping 15...');
// //         continue;
// //     }
// //     console.log(i);
// // }
// // USES WHEN DONT KNOW NUMBER OF TIMES LOOP RUN
// // WHILE LOOP,  DO WHILE LOOP
// // INITIALIZE outside while loop
// // just condition in bracket
// // increment value will write after console

// let i = 0;

// // // while(i <= 3){
// // // console.log('Number is ' + i);
// // // i++;
// // // }

// // // LOOP OVER ARRAY
// // const arr = [1, 2, 3, 4];
// // while(i < arr.length){
// //     console.log(arr[i]);
// //     i++;
// //     }

// // // nesting while loops
// // while(i <= 3){
// //     console.log('Number is ' + i);

// //     let j = 0;
// //     while(j <= 3){
// //         console.log(`${i} - ${j} = ${i - j}`);
// //         j++;
// //         }

// //         i++;
// //     }

// // DO WHILE LOOPS RUNS even the condition is false
// // SUGGEST NOT USE
// do {
//     console.log('number ' + i);
//     i++;
// } while (i <= 20);

// // Task
// // print numbers 1 to 100

// for (i = 0; i <=100; i++){
//     if (i % 3 === 0 && i % 5 === 0){
//         console.log('FizzBuzz');
//     }
//     else if (i % 3 === 0 ){
//         console.log('Fizz');
//     } else if (i % 5 === 0){
//         console.log('Buzz');
//     } else {
//         console.log(i);
//     }
// }

// // with while loop

// let i = 0;
// while (i <= 100){
// if (i % 3 === 0 && i % 5 === 0){
// console.log('fizzBuzz');
// }
// else if (i % 5 === 0){
// console.log('buzz');
// }
// else if (i % 3 === 0){
// console.log('fizz');
// } else {
//     console.log(i);
// }
//     i++;
// }

// FOR OF LOOPS TO CREATE ARRAY
// const items = ["book", "chair"];

// // for (let i = 0; i < items.length; i++){
// //     console.log(items[i]);
// // } //**NOT do this do this instead**//
// for (const item of items) {
//   console.log(item);
// }

// // Array of objects in it of loop
// const users = [ {name: "ammara"} , {name: "sami"}];

// for (const user of users) {
//   console.log(user.name);
// }

// // loops Of string
// const str = 'hello ammara';
// for (const letter of str) {
//     console.log(letter);
// }

// // loops over of maps
// const map = new Map();
// map.set('name', 'john');
// map.set('age', 30);

// for (const [key, value] of map){
//     console.log(key, value);
// }

// // FOR IN loop
// // object to object lietral
// const colorObj = {
//     color1: 'red',
//     color2: 'yellow',
//     color3: 'green',
//     color4: 'pink',
// }

// for(const key in colorObj){
// console.log(key, colorObj[key]);
// }

// // FOR IN LOOP array
// const colorArr = ['red', 'green'];
// for (const key in colorArr){
//     console.log(colorArr[key]);
// }

// // ARRAY FOREACH
// const socials = ['ammara', 'aniya'];

// // socials.forEach(function(element){
// // console.log(element);
// // });

// // another way
// socials.forEach((element, index, arr) => console.log(`${index} - ${element}`, arr));

// take out only even number TASK
 const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

 const evenNumbers = numbers.filter((number) => number % 2 !== 0);
 console.log(evenNumbers);