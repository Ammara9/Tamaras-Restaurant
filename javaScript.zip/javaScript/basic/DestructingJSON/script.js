// // // *** Destructure Object ***
// // const firstName = 'ammara';
// // const lastName = 'shakeel';
// // const age = 29;

// // const person = {
// //     firstName: firstName,
// //     lastName: lastName,
// //     age: age
// // };

// // console.log(age); //can call with person.age//

// // // DESTRUCTURING 

// // const todo = {
// //     id: 1,
// //     title: 'Take children',
// //     user: {
// //         name: 'ammara',
// //     },
// // };

// // const { 
// //     id: todoId, 
// //     title, 
// //     user: {name}, 
// // } = todo; //a way to destruct data | can call direct with key//

// // // console.log(name);
// // console.log(todoId);

// // // *** destructure array ***
// // const numbers = [1, 2, 3, 4, 5];

// // // const [first, second] = numbers; //take first and second number//

// // // REST OPERATOR ...rest (to get rest elements)
// // const [first, second, ...rest] = numbers;

// // console.log(first, second , rest);





// // //****  JSON from js *******
// // // BLOG POST
// // const post = { //this is js object//
// // id: 1,
// // title: 'post one'
// // };

// // // we must have to convert into JSON string because json string have "" in keys but js dont
// // const str = JSON.stringify(post);
// // // in this step we are not able to reach post keys with chaining console.log(post.id);

// // // we must PARSE it before chaining (must dec new variable in every step)
// // const obj = JSON.parse(str);
// // console.log(obj.id);

// // // multiple array object
// // const posts = [
// //     {
// //         id: 1,
// //         titile: 'part one'
// //     },
// //     {
// //         id: 2,
// //         titile: 'part two'
// //     }
// // ];

// // const str1 = JSON.stringify(posts); //convert to JSON//
// // const obj1 = JSON.parse(str1); //JSON TO OBJECT//
// // console.log(obj1);


// // OBJECT LITERAL TASK()
// // STEP 1
// const library = [
//     {
//         title: 'javascript',
//         author: 'ammara',
//         status: {
//             own: true,
//             reading: false,
//             read: false
//         }
//     },
//     {
//         title: 'JSON',
//         author: 'ammara',
//         status: {
//             own: true,
//             reading: false,
//             read: false
//         }
//     },
//     {
//         title: 'REACT',
//         author: 'ammara',
//         status: {
//             own: true,
//             reading: false,
//             read: false
//         },
//     },
    
// ];

// library[0].status.read = true;
// library[1].status.read = true;
// library[2].status.read = true;

// //STEP:3 destructure the data change first title variable to firstbook

// const { title: firstBook } = library [0];

// const str = JSON.stringify(library);

// console.log(str);