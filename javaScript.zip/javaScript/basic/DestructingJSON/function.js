// // // Function SCOOP
// // const x = 100;

// // function sayHello() {
// //   console.log("hello");
// // }
// // sayHello();

// // function add(num1, num2) {
// //   //parameters//
// //   console.log(num1 + num2); //what to do//
// // }

// // add(5, 4); //argument//

// // // RETURNING
// // function substract(num1, num2) {
// //   return num1 - num2;
// // }
// // const result = substract(10, 2);
// // console.log(result);
// // // console.log(result, substract(3, 2)); //can add more values//

// // function registerUser(user = "bot") {
// //   //default params//
// //   return user + " is registered";
// // }
// // console.log(registerUser());

// // // REST PARAMS
// // function sum(...numbers) {
// //   return numbers;
// // }
// // console.log(sum(1, 2, 3));

// // // OBJECT
// // const user = {
// //   id: 1,
// //   name: "ammara",
// // };

// // function loginUser(user) {
// //   return `The user ${user.name} with the id ${user.id} is logged in.`;
// // }
// // console.log(loginUser(user));

// // // can add multiple user object via console
// // console.log(
// //   loginUser({
// //     id: 2,
// //     name: "shakeel",
// //   })
// // );

// // // Arrays with function as params (get random numbers)
// // function getRandom(arr) {
// //   const randomIndex = Math.floor(Math.random() * arr.length);

// //   const item = arr[randomIndex];
// //   console.log(item);
// // }

// // getRandom([1, 2, 4, 5, 6, 7, 8, 9]);

// // // function add() {
// // //   const y = x + 50; //we cant reach it outside the body in anyway//
// // //   console.log(y);
// // // }
// // // add();

// // // //BLOCK SCOPE
// // // // var, let , const

// // // //if block
// // // if (true) {
// // //   const y = 100;
// // //   console.log(x + y);
// // // }

// // // //for loop block (let)
// // // for (let i = 0; i <= 10; i++) {
// // //     console.log(i);
// // // }

// // // //DIFFERENCE bw const let var
// // // if (true){
// // //     const a = 500;
// // //     let b = 600;
// // //     var c = 700;
// // // }

// // // // NESTED FUNCTION (function in function)

// // // function first(){
// // //     const a = 100;

// // //     function second (){
// // //         b = 101;
// // //         console.log(x + y);
// // //     }
// // //     second();
// // // }
// // // first();

// // // Function Declaration
// // function addDollarSign(value){
// // return '$' + value;
// // }
// // console.log(addDollarSign(100));

// // // function expression
// // const addPlusSign = function(value){
// // return '+' + value;
// // }; // semi colums must add after expression//
// // console.log(addPlusSign(100));

// // // **** ARROW FUNCTION **** shorter (2015)
// // const addd = (a, b) => a +b; //if u have single params u can remove brakets//
// // console.log(addd(1, 3));

// // // object in ARROW FUNCTION
// // const createObj = () => ({ //to create a object in function, the syntax is df ({ must be in (//
// // name : 'ammara',
// // });
// // console.log(createObj);

// // // array in ARROW function
// // const numbers = [1, 2, 3, 4, 5, 6];
// // numbers.forEach((n) => console.log(n));

// // IIFE IMMEDIATLY INVOKED FUCTION EXPRESION
// // coming soon

// // //TASk function
// // FIRST WAY
// // function getCelsius(tempF){
// //     return (tempF - 32) * (5 / 9);

// // };
// // console.log(getCelsius(32));

// // // one line arrow funct
// // // SECOND WAY
// // const getCelsius = tempF => (tempF - 32) * (5 / 9);
// // console.log(`The Temperature is ${getCelsius(50)} \xB0C.`);

// // // //third way
// // function getCelsius(f){
// //     const celsius = (f - 32) * (5 / 9);
// //     return celsius;
// // }
// // console.log(getCelsius(32));

// // // Math min max TASK
// // //oneway SPREAD METHOD TWO CONST AND TWO OBJECT RETURN
// // function minMax (arr){
// //     const min = Math.min(...arr);
// //     const max = Math.max(...arr);
// //     return {
// //         min,
// //         max
// //     };
// // }
// // console.log(minMax([1, 2, 3, 4, 5]));
// // // second  way arrow function:
// // const minMax = (arr) => Math.min(...arr);
// // console.log(minMax([0, 1, 2, 3]));

// // // TASK 3 NORMAL WAY
// // function rec (l, w){
// //     const a = l * w;
// //     return a;
// // }
// // console.log(rec(10,5));

// // // task second way | IIFE | cant call outside the function
// // (function (length, width){
// // const area = length * width;
// // // console.log('The area of rectangle with a length ' + length + ' and with a width ' + width + ' is ' + area + '.');
// // console.log(`The area of rectangle with a length ${length} and with a width ${width} is ${area}.`);
// // })(10, 5);

// // // EXECUTION CONTEXT
// // const m = 1;
// // const n = 2;

// // function getSum (m1, n1){
// //     const sum = m1 + n1;
// //     return sum;
// // }

// // const sum1 = getSum (m, n);
// // const sum2 = getSum (10, 1);

// // console.log(sum1, sum2);

// // IF ELSE STATMENTS (it will show on console if its true BUT if it false it will not run)
// if (true) {
//   console.log(`This is the IF statement.`);
// }

// const x = 10;
// const y = 5;
// const z = 5;

// if (x >= y) {
//   console.log(`${x} greater or equal ${y}`);
// }

// if (x <= y) {
//   console.log(`${x} less or equal ${y}`);
// }

// if (x === y) {
//   console.log(`${x} equal ${y}`);
// }

// if (x !== z) {
//   console.log(`${x} is not equal ${z}`);
// }
// //IF with ELSE
// if (x === y) {
//   console.log(`${x} equal ${y}`);
// } else {
//   console.log(`${x} is not equal to ${y}`);
// }

// // IF ELSE Nesting
// const d = new Date();
// const hour = d.getHours();
// const min = d.getMinutes();

// // console.log(d);
// // console.log(hour);
// // console.log(`${hour}:${min}`);

// if (hour < 12) {
//   console.log("Good Morning");
// } else if (hour < 18) {
//   console.log("Good afternoon");
// } else {
//   console.log("Good Night");
// }

// // IF NESTING
// if (hour < 12) {
//   console.log("Good Morning");
//   if (hour === 6) {
//     console.log("Wake Up DEAR!");
//   }
// } else if (hour < 18) {
//   console.log("Good afternoon");
// } else {
//   console.log("Good Night");
//   if (hour >= 20) {
//     console.log("zzzzzz");
//   }
// }

// // Multiple conditions in single if (&& and) (|| or)
// if (hour >= 7 && hour < 3) {
//   //between this interval//
//   console.log("This is work time");
// }

// if (hour === 6 || hour === 20) {
//   //exact time//
//   console.log("Brush your teeth :)");
// }

// //***** SWITCHES ****
// const k = new Date(2023, 5, 10, 8, 0, 0);
// const month = k.getMonth();

// switch (month) { //can put true in month if we use < >==//
//   case 1:
//     console.log("Its is Jan.");
//     break;
//   case 2:
//     console.log("Its is Feb.");
//     break;
//   case 3:
//     console.log("Its is Mars.");
//     break;
//   case 4:
//     console.log("Its is April.");
//     break;
//   default: //default dnt need break//
//     console.log("it is not jan, feb, mars, april.");
// }

// // calculator challange 
// // TASK one way
// function calculator(num1, num2, operator){
//     let result;

// switch(operator){
//     case '+': result = num1 + num2;
//     break;
//     case '-': result = num1 - num2;
//     break;
//     default: 
//     result = 'invalid operator';
// }
// console.log(result);
// return result;
// }
// calculator(1, 2, '+');

// // *** TRUTHY & FALSY values***
// // truthy
// // - everything else which is not false
// // - true
// // - '0' 0 in String
// // -'false' false in String
// // -[]empty Array
// // -{} empty Object
// // - function empty function name(params) {
  
// // }
// const children = 0;

// if (!isNaN(children)){
//     console.log(`you have ${children} children`);
// } else {
//     console.log('please entre number of children'); //to not get this use in params after !== undefined or with !isNaN()//
// }

// // truth value checing for empty array
// const posts = [1];
// if (posts.length){
//   console.log('List Posts');
// } else {
//   console.log('No posts'); //not showing this(post.length show this)//
// }

// // Checking for empty object
// const user = {
//   name: 'ammara',
// }
// console.log(user.length); //we cant use length direct with object as we did with array//
// if(user){
//   console.log('List user');
// } else {
//   console.log('no user');
// }

// // LOGICAL OPERATORS && ||
// // df in this two operator is when we use && first value must be true if first value is false everything will become false
// // in || operator dont need to be true by first value
// console.log(10 > 20 && 30 > 15 && 40 > 30); 
// console.log(10 > 20 || 30 > 15);

// //  && will return first falsy value or last value
// // no falsy value, last value showed
// // if first value falsy showed first
// // 0 is a false value
// let a;
// // a = 0 && 20;
// a = 10 && 22 && 30;
// console.log(a);

// const posts = ['post one', 'post two'];
// posts.length > 0 && console.log(posts[0]); //**imp API***//

// //  || first comes truthy value or last value
// let b; 
// b = 0 || 20 || 30;

// console.log(b);

// // ?? - returns the right side operand when the left is null or undefined
//  let c;
//  c = 10 ?? 20; //first value//
//  c = null ?? 20; //last value//
//  c = 10 ?? null ?? 20; //first value//
//  console.log(c);

// //  LOGICAL ASSIGNMENTS assign operators
// // ||= assign right value only if left v falsy
// let a = false;

// // if (!a){
// // a = 10;
// // }
// // //  a = a || 10;

// a ||= 10;
// console.log(a);

// // &&= assign right value only if left v truthy
// let b = false;

// b &&= 10;
// console.log(b);

// // ??= assign right value only if left v null or undefined
// let c = false;
// if(c === null || c === undefined){
//   c = 20;
// }
// // c ??= 10;
// console.log(c);

// TERNARY OPERATORS

const age = 18;
// using if satameny
if(age >= 18){
console.log('can vote');
} else {
  console.log('can not vote');
}

// using TERNARY OPERATOR
// three conditions
// ? is used as if
// : is used as else
// const age variable is giving age value

age >= 18 ? console.log('can vote') : console.log('can not vote');

// assign a variable direct and conditional value to using a ternary op
const canVote = age >= 18 ? true : false;
// two conditions
const canVote2 = age >= 18 ? 'you can vote' : 'you can not vote';
console.log(canVote2); 

// // multiple statement in ternary operator
// const auth = false; //change to true to see redirection//
// let redirect;

// if(auth){
//   alert('welcome to dashboard');
//   redirect = '/dashboard';
// } else {
//   alert('acces denied');
//   redirect = '/login';
// }

// console.log(redirect);

// const aut = true;

// const redirect = aut ? (alert('welcome'), '/dashboard') : (alert('denied'), '/login');
// console.log(redirect);

// ternary op with one condition 
// in ternary we must put second condition
// 2 con is : null ;