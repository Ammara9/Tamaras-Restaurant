// // this is comment... command + arrow upp + /
// // command + arrow up + left/right (to navigate in line)
// // option + left/right (move in between line)
// // OPTION + ARROW UPP + button down to copy multiple line without select it
// // highlight the word and command + d to change it on every place in script


// let firstName = "Ammara";
// let lastName = "Shakeel";

// console.log(firstName, lastName);

// const ammara = {
//     name : 'shakeel'
// };
// ammara.name = 'john';
// ammara.lastName = 'sami';

// console.log(ammara);

// const login = {
//     name : 'ammara',
//     last : 'shakee',
// };

// login.name;
// login.last;

// console.log(login);

// // string
// const name = 'ammara';
// // number
// const temp = 90;
// // boolean
// const hasKids = true;

// // symbol
//  const id = Symbol ('id');

// //  Function
// function me () {
//     console.log('hello');
// }

// // change the variable to get the specific output
// const output = me;

// console.log(output, typeof output);


// // refcrence type
// const name = 'john';

// let person = {
//     name : 'brad',
// }
// let newName = name;
// newName = 'johnathan';

// // result on console log
// console.log(name, newName);

// // TYPE CONVERSION
// // string to number {Number() function}

// let amount = '100';

// amount = Number(amount);
// console.log(amount);

// // change number to string

// let amount = 100;

// amount = String(amount);
// console.log(amount, typeof amount);

// // OPERATORS
// // 1. ARITHEMATIC

// let x;
// x = 5 + 5;

// // CONCATENATION
// x = 'hello' + ' ' + 'world';

// // EXPONENT
// x = 2 ** 3;

// //********************/ INCREMENT / DECREMENT

// x = 1;
// x++;
// x--;

// console.log(x);

// // Assignment operators *******
//  x = 20;

//  // it means it will plus the above x-value to x here
//  x += 5;

// //  it will minus to all above  values
// x -= 6;

// //  mutiply
// x *= 2;

//  console.log(x);

// COMPARISION OPERATORS ***************
// x = 2 means we declare a value of x but when we use ==
// its a comparision == , it evalutes only value

// x = 2 == 2;

// when comes === it evalute value and typeof
// means if we put string in place of number it will show false
// if we put number in string it shows false to but its not same with ==

// examples

// x = 2 === 2; // true //-->

// x = 2 === '2'; // false //-->

//  != means not equals
// x = 2 != 2; // false //-->

// x = 2 != 5; // true //-->

// //  for evalute typeof
// x = 2 !== 5;

// console.log(x);

