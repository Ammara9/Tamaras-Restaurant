// let x;

// // Arrya literal (creats array object)
// const numbers = [12, 45, 33, 29, 39];

// // Arrays constructor (create array object)
// const  fruits = new Array('Apple', 'Grape', 'Orange');


// x = numbers[3];

// //  can do addition in arrays
// x = numbers[0] + numbers[3] + numbers[1];

// // can write a line with array (literal template)
// x = `My favorite fruit is ${fruits[0]} and ${fruits[1]}. `;

// // length property
// x = numbers.length;


// // u can change / replace the element from another elemnt
// fruits[1] = 'Pear';

// // u can add fourth3 elemnt in it, with two solutions
// fruits[3] = 'Strawberry'; //first//
// fruits[fruits.length] = 'Blueberry'; //second way of adding element//

// //  must call it to show the results
// x = fruits;

// console.log(x);

// // ARRAY METHODS
// const arr = [1, 2, 3, 4, 5];

// // arr.push(6); // to add another elemnt in last via method ***use this****
// // arr.pop(); //remove last elemnt//

// // arr.unshift(0); //add element in start of array//
// // arr.shift(); //remove element from begining//

// // arr.reverse(); //reverse whole array//

// // x = arr.includes(5); //true or false based on what value we have in array//
// // x = arr.indexOf(5); //where is 5 located in array//

// // x = arr.slice(0, 4); //its remove the element with its index but we must show 0 to the index number, not change the original array//
// // // console.log(x, arr);

// // x = arr.splice(1, 4);

// x = arr.splice(0, 4).reverse().toString();
// console.log(x);

// NESTING two arrays

// let x; //output varaible//

// const fruits = ['Apple', 'Banana', 'Pear'];
// const berries = ['Strawberry', 'Blueberry', 'Rasberry'];
// const exotic = ['Pineapple', 'Kiwi'];

// fruits.push(berries, exotic); //two arrays in one//

// x = fruits[4][0]; //so we can take out value from array of arrray//

// // create a new array and nest all array in this new without pushing

// const allFruits = [fruits, berries, exotic];

// x = allFruits[2][1]; 

// // CONCAT METHOD
// x = fruits.concat(berries, exotic); //can collect all in one simple array//

// //  SPREAD OPERATOR (...)
// x = [...fruits, ...berries]; //same result as concat method, collect all array in one//

// // FLATTEN ARRAY (arrays in arrays)
// const arr = [1,2, [3, 4], 5, [6, 7], 8];
// //index [0,1, [2/0, 2/1], 3 [4/0, 4/1], 5];

// // x = arr.flat(); //flatten it no more nested//

// x = arr.flat().indexOf(5); //got the right answer//

// // STATIC METHODS ON ***** ARRAY OBJECT *****
// x = Array.isArray(allFruits); //if put 'string' its says false//
// x = Array.from('12345'); //form an array  ['f', 'r', 'o', 'm'] //

// // combine the different array with ARRAY OBJECT
// const a = 1;
// const b = 2;
// const c = 3;

// x = Array.of(a, b, c);


// console.log(x);

// // CHALLANGE TASK(1)
// const arr = [1, 2, 3, 4, 5];
//  arr.push(6);
//  arr.unshift(0);

//  arr.reverse();

//  console.log(arr);

// // CHALLANGE TASK(2)

// const arr1 = [1, 2, 3, 4, 5];
// // arr1.pop(); //remove last element//
// // arr1.splice(4); //remove element with index number//
// // arr1.slice(1, 2); //its NOT working//

// const arr2 = [5, 6, 7, 8, 9, 10];

// // const arr3 = [arr1, arr2] //one way to collect array in array//
// // arr3 = [...arr1, ...arr2]; //got the same result with SPREAD OPERATOR//
// const arr3 = arr1.slice(0, 4).concat(arr2); //another right result, 0 is basic destination//
// console.log(arr3);

// // ***OBJECT LITERAL****
// // Array person = variable, name = key, ammara = value
// let x; //output variable//

// const person = {
//     name: 'ammara',
//     age: 29,
//     location: 'Stockholm',
//     isAdmin: true,
//     address: { //object within an object//
//         street: '123 main street',
//         houseNo: 5,
//         isAppartment: true
//     },
//     hobbies: ['music', 'swimming', 'reading', 'cooking'] //its an ARRAY in object//
// };

// // console.log(person.name); //a way to get the result direct//

// // // x = person.age; //another way to get result with x variable //
// // x = person['location']; //via array//

// // x = person.address.houseNo;

// // x = person.address.street;
// // x = person.address['street']; //man an använda den också//
// // x = person.hobbies[3]; 

// //Array in object can be manipulated as an normal array

// // x = person.hobbies;
// // // x = person.hobbies.slice(0, 2); //from 0 index upto 1 index shows//
// // x = person.hobbies.splice(0, 3);  //from 0 index upto 2 index shows//
// person.name ='Shakeel' //can change the object:person key:name value//
// person['isAdmin'] = false; //changes from true to false//

// // delete person.age; //delete property//
// person.hasChildren = true; //add boolean property(key and value)//

// // can create a FUNCTION in person

// person.Greetings = function () { //person.greet hämtar data från person//
//     console.log(`Hello! My name is ${this.name} and I am ${this.age} years old.`); //template literal in console //
// };

// person.Greetings();

// x = person;
// console.log(x);

//*** Object spread operator and method ****/
// create an object with an empty object
let x;

// const todo = {}; // {}; is same as new Object();//
const todo = new Object();

todo.id = 1;
todo.name ='Buy Milk';
todo.completed = false;

x = todo;

const person = {
    address: {
        coords: {
            lat: 42.9,
            lng: -71.1,
        },
    }, 
};

x = person.address.coords.lat;

const obj1 = {a: 1, b: 2, c: 3};
const obj2 = {d: 4, e: 5, f: 6};

// const obj3 = {obj1, obj2}; //object in object(nested)//
const obj3 = {...obj1, ...obj2}; //spread operator to get obj3 as one object(not nested)//
const obj4 = Object.assign({g: 7 }, obj1, obj2); //create an empty object, can put value direct in curly brackets//

const todos = [ //object in array//
    { id : 1, name: 'buy' },
    { id : 2, name: 'kids' },
    { id : 3, name: 'trash' },
];

x = todos[2].name; //can get via index number and name property//

x = Object.keys(todo); //to get all the keys in one gone//

x = Object.keys(todo).length; //only way to get the lenghth of object//

x = Object.values(todo);
x = Object.entries(todo);

X = todo.hasOwnProperty('name'); //to check the if it have a property named in argument//
console.log(x);