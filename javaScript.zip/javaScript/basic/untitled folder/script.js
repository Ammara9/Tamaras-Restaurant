// // OPERATORS
// // 1. ARITHEMATIC

// let x;
// x = 5 + 5;

// // CONCATENATION
// x = 'hello' + ' ' + 'world';

// // EXPONENT
// x = 2 ** 3;

// //********************/ INCREMENT / DECREMENT

// x = 1;
// x++;
// x--;

// console.log(x);

// // Assignment operators *******
//  x = 20;

//  // it means it will plus the above x-value to x here
//  x += 5;

// //  it will minus to all above  values
// x -= 6;

// //  mutiply
// x *= 2;

//  console.log(x);

// COMPARISION OPERATORS ***************
// x = 2 means we declare a value of x but when we use ==
// its a comparision == , it evalutes only value

// x = 2 == 2;

// when comes === it evalute value and typeof
// means if we put string in place of number it will show false
// if we put number in string it shows false to but its not same with ==

// examples

// x = 2 === 2; // true //-->

// x = 2 === '2'; // false //-->

//  != means not equals
// x = 2 != 2; // false //-->

x = 2 != 5; // true //-->

//  for evalute typeof
x = 2 !== 5;

console.log(x);