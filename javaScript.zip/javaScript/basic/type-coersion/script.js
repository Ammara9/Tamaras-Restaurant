// // string to number, numebr to string
// // true = 1, false = 0

// let x;

// x = 5 + 5 ;

// console.log(x, typeof x);

// // String concatination

// let x;

// const name = 'ammara';
// const age = 29;

// // x = 'Hello, my name is ' + name + ' and i am ' + age + ' years old';

// // TEMPLATE LITERAL backtags
// // in template literal we use $ sign to call a variable
// x = `Hello, my name is ${name} and i am ${age} years old`;

// // String properties dont use func and methods use func
// const s = new String ('helo world'); // method //-->
// // const s = 'hello world';

// // x = s.length; // property //-->

// // x = s[0]; // access value by key (only one value) //-->
// // console.log(x);

// // MTHOD

// // const s = 'hello world';

// x = s.toUpperCase();

// x = s.charAt();

// x = s.replace('world', 'john');

// x = s.includes('world');

// x = s.valueOf();

// x = s.split(' ');

// console.log(x);

// // CHALLANGE to uppercase

// const myString = 'developer ';

// // myNewString = myString.slice(1); //slice method removes strings by number//-->


// // solution 1
// // myNewString = myString.charAt(0).toUpperCase() + myString.slice(1); //call the variable connect with charAt number 0 change it to uppercase and then slice it which removes 1 char and shows remaining//-->

// // solution 2
// // myNewString = myString.charAt(0).toUpperCase() + myString.substring(1);

// // solution 3
// // myNewString = myString[0].toUpperCase() + myString.substring(1);

// // solution 4 literal (backtags, dollar sign and curly brackets)

// myNewString = `${myString[0].toUpperCase()}${myString.substring(1)}`;

// console.log(myNewString);

// my own challange

// // Numbers

// let x;

// const num = new Number(5); // method //-->

// x = num.toString(); // convert to string //-->

// x = num.toString().length; //cant take length alone, must convert to string with length//-->

// x = num.toFixed(2); // give the two decimal ans//-->

// x = num.toPrecision(2); // precised value of decimal number avround //-->

// x = num.toExponential(2);

// x = num.toLocaleString('en-US'); //number will be return in ur local langugae //-->

// x = num.valueOf();

// x = Number.MAX_VALUE; // property, shows largest number we can use in js //-->
// x = Number.MIN_VALUE;

// console.log(x);

// // MATH OBJECTS
// let x;

// x = Math.sqrt(9); //square root of number in func//-->

// x = Math.abs(-5);// method abs number of -5 is 5//-->

// x = Math.round(9.88);// method //-->
// x = Math.ceil(4.2); // round up become 5 //-->
// x = Math.floor (4.9); //round down it will be 4 //-->

// x = Math.pow (2, 3); //power 3 is a power of 2 = 2^3= 8  //-->

// x = Math.min(2, 3, 4, 5);// it will show the smallest num from func //-->
// x = Math.max(2, 3, 4, 5);// it will show the largest num from func //-->

// x = Math.random() * 100 + 1; // gives random decimal num to 100 //-->
// x = Math.floor(Math.random() * 100 + 1); // random with floor(avround) gives u whole num //-->

// console.log(x);

// // challange
// const x = Math.floor(Math.random() * 100 + 1); 
// const y = Math.floor(Math.random() * 50 + 1); 

// const sum = x + y;
// const  dif = x - y;
// const mul = x * y;
// const div = x / y;
// const per = x % y;

// const sumO = `${x} + ${y} = ${sum}`;
// //const difO = `${x} - ${y} = ${dif}`;
// //const mulO = `${x} * ${y} = ${mul}`;
// //const divO = `${x} / ${y} = ${div}`;
// //const perO = `${x} % ${y} = ${per}`;

// console.log(sumO);

// // my own solution to challange
// let x = Math.floor(Math.random() * 100 + 1); 
// let y = Math.floor(Math.random() * 50 + 1); 

// // let z = x + y; // use different variable for every funct to get everyone working together in console //-->
// let z = x - y;

// // let sum = `${x} + ${y} = ${z}`;
// let dif = `${x} - ${y} = ${z}`;

// console.log(dif);

// // DATE AND TIME
// // DATE OBJECT 

// let d; // variable //-->

// d = new Date();  //object func//-->

// d = d.toString(); //change object to string //-->

// // if we want to know the day of any date (month is 0 index)
// // jan-0, feb-1, mars-2, etc dec-11 
// d = new Date(2023, 9, 17, 12, 30, 00); // 12, 30, 00 hour, min, sec//-->
// d = new Date('2023-09-17T12:30:00'); // MONTH IS NOT 0 INDEX //-->
// d = new Date('09/17/2029 12:30:00'); // MONTH IS NOT 0 INDEX //-->

// d = Date.now(); // 1697642443677 //-->

// d = new Date();
// d = d.getTime();

// d = new Date(1697642443677); //this is how it shows time in console //-->

// // to get milliseconds func
// d = Math.floor(Date.now() / 1000); // 1697642640 //-->

// // d = new Date(1697642640); // wrong answer//
// console.log(d);

// DATE METHODS ()
let x;

let d = new Date(); //d is equal to function//

// x = d.toString(); //combine one function to another to get result//
// x = d.getTime();
// x = d.valueOf();


// x = d.getFullYear();
// x = d.getMonth() + 1;
// x = d.getDate();
// x = d.getDay();
// x = d.getHours();
// x = d.getMinutes();
// x = d.getSeconds();
// x = d.getMilliseconds();

// // literal template to write down date and time on console
// x = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;

// // API way of doing date and time

// // x = Intl.DateTimeFormat('en-US').format(d);

// // x = Intl.DateTimeFormat('en-GB').format(d);

// x = Intl.DateTimeFormat('default').format(d);
// x = Intl.DateTimeFormat('default', { month: 'long' }).format(d); //full month name//
// x = Intl.DateTimeFormat('default', { month: 'short' }).format(d); //short form of month name//

x = d.toLocaleString('default');


console.log(x);
